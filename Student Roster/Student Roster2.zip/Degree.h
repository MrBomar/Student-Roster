#pragma once

enum Degree { NONE, SECURITY, NETWORK, SOFTWARE };